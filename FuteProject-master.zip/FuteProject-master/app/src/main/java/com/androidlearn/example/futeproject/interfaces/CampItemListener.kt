package com.androidlearn.example.futeproject.interfaces

import android.view.View

interface CampItemListener {
    fun onListItemClick(view: View, id: String)
}