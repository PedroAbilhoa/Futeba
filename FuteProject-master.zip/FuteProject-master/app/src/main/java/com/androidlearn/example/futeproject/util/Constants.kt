package com.androidlearn.example.futeproject.util

object Constants {
    const val BASE_URL = "https://api.api-futebol.com.br/v1/"
    const val API_KEY = "live_27af9e02525136e554fc0431e78c7e"
}